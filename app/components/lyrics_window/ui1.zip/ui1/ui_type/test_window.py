import sys
import time

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(809, 370)
        self.gridLayout = QtWidgets.QGridLayout(Form)
        self.gridLayout.setObjectName("gridLayout")
        self.text1_scrollArea = QtWidgets.QScrollArea(Form)
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(24)
        self.text1_scrollArea.setFont(font)
        self.text1_scrollArea.setWidgetResizable(True)
        self.text1_scrollArea.setObjectName("text1_scrollArea")
        self.text1_scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.text1_scrollArea.setStyleSheet('QScrollArea{border:none}')

        self.text1_label = QtWidgets.QLabel()
        self.text1_label.setGeometry(QtCore.QRect(0, 0, 789, 171))
        self.text1_label.setFont(font)
        self.text1_label.setObjectName("text1_label")

        self.text1_scrollArea.setWidget(self.text1_label)
        self.gridLayout.addWidget(self.text1_scrollArea, 0, 0, 1, 1)
        self.text2_scrollArea = QtWidgets.QScrollArea(Form)
        self.text2_scrollArea.setFont(font)
        self.text2_scrollArea.setWidgetResizable(True)
        self.text2_scrollArea.setObjectName("text2_scrollArea")
        self.text2_scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.text2_scrollArea.setStyleSheet('QScrollArea{border:none}')

        self.text2_label = QtWidgets.QLabel()
        self.text2_label.setGeometry(QtCore.QRect(0, 0, 789, 171))
        self.text2_label.setObjectName("text2_scrollAreaWidgetContents")
        self.text2_scrollArea.setWidget(self.text2_label)
        self.gridLayout.addWidget(self.text2_scrollArea, 1, 0, 1, 1)

        self.text1_label.setText('123dasjfkashfkasjfkasjkfjasklfjasklfj')
        self.text1_label.setAlignment(Qt.AlignCenter)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    form = QtWidgets.QWidget()
    MainUi = Ui_Form()
    MainUi.setupUi(form)
    form.show()
    sys.exit(app.exec_())