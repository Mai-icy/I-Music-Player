#!/usr/bin/python
# -*- coding:utf-8 -*-
import random
import sys
import time
import json
import os
import copy
import threading
from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent

from components.player.lyric_player import LrcPlayer
from components.player.music_stream_queue import MusicStreamQueue


class MediaPlayer(object):
    def __init__(self, player_carrier: QMainWindow, lyrics_window):
        # 读取文件
        self.player_carrier = player_carrier  # 自定义类的传递是传引用
        self.player_carrier.player = QMediaPlayer()  # 给予载体ui player控件
        self.play_stream = MusicStreamQueue('temporary')
        self.backup_play_stream = self.play_stream

        self.lrc_play = LrcPlayer(player_carrier, lyrics_window)


        self.total_duration = 0
        self.play_stream_mode = 0  # 0顺序播放 1随机播放 2单曲循环

        self.reload_song()

        self.player_carrier.player.stateChanged.connect(self.__play_over_event)  # 播放完毕连接的函数

    def load_queue(self, play_stream: MusicStreamQueue):
        self.player_carrier.player.stop()
        self.play_stream = play_stream
        self.backup_play_stream = self.play_stream
        self.lrc_play.load_music_stream_queue(self.play_stream)
        self.reload_song()

    def set_lyrics_window(self, lyrics_window):
        self.lrc_play.lyrics_window = lyrics_window

    def __play_over_event(self) -> None:
        if self.player_carrier.player.state() == 0 and self.player_carrier.player.mediaStatus() == 7:  # 歌曲播放完毕
            if self.play_stream_mode == 2:
                self.play_pause_player()
                self.lrc_play.restart_thread()  # 确保歌词重新打开
            else:
                self.next_song()
        else:  #
            return

    def __reload_song_data(self) -> None:
        # print(self.player_carrier.player.mediaStatus())
        while self.player_carrier.player.mediaStatus() == 2:
            pass
        # print(self.player_carrier.player.mediaStatus())
        time.sleep(0.1)  # 还要过0.1秒才能获取到时间
        self.total_duration = self.player_carrier.player.duration()
        self.play_pause_player()  # 确保在reload之后播放音乐
        self.lrc_play.restart_thread()
        try:
            self.player_carrier.progress_slider.setMaximum(int(self.total_duration))
            self.player_carrier.progress_slider.setMinimum(0)
            self.player_carrier.progress_slider.setValue(0)
        except AttributeError:
            pass

    def reload_song(self) -> None:
        self.player_carrier.player.setMedia(QMediaContent(QUrl(self.play_stream.now_song_info['songPath'].replace('\\', "/"))))
        time_text = self.play_stream.now_song_info['duration'].split(':')
        self.player_carrier.progress_slider.setMaximum(int(self.total_duration))
        self.player_carrier.progress_slider.setMinimum(0)
        self.player_carrier.progress_slider.setValue(0)
        self.total_duration = (60 * int(time_text[0]) + int(time_text[1])) * 1000

    def play_pause_player(self) -> None:
        if self.player_carrier.player.state() == 1:
            self.player_carrier.player.pause()
            self.lrc_play.is_pause = True
        elif self.player_carrier.player.state() == 2 or self.player_carrier.player.state() == 0:
            self.player_carrier.player.play()
            self.lrc_play.is_pause = False
        try:
            self.player_carrier.progress_slider.setValue(self.player_carrier.player.position())
        except AttributeError:
            pass

    def next_song(self) -> None:
        """
        Play the next song in queue

        :return: None
        """
        self.play_stream.next_song()
        self.reload_song()

    def last_song(self) -> None:
        self.play_stream.last_song()
        self.reload_song()

    def set_play_stream_mode(self, mode: int) -> None:  # 0顺序播放 1随机播放 2单曲循环
        if self.play_stream_mode == 1 and mode != 1:
            now_music_path = self.play_stream.now_music_path
            now_lyric_path = self.play_stream.now_lyric_path

            self.play_stream = self.backup_play_stream.get_random_song_queue()

            self.play_stream.music_stream_list.remove(now_music_path)
            self.play_stream.lyric_stream_list.remove(now_lyric_path)
            self.play_stream.music_stream_list.insert(0, now_music_path)
            self.play_stream.lyric_stream_list.insert(0, now_lyric_path)  # 把当前播放的曲目置顶
            # todo 播放列表变化 变成新生成的随机列表
            self.lrc_play.play_stream = self.play_stream  # 同步到歌词播放的play_stream
        elif self.play_stream_mode != 1 and mode == 1:
            self.play_stream = copy.deepcopy(self.backup_play_stream)
            # todo 播放列表变化 变回原来的列表
            self.lrc_play.play_stream = self.play_stream  # 同步到歌词播放的play_stream
        self.play_stream_mode = mode

    def set_position(self, position: int) -> None:  # position为毫秒数
        self.player_carrier.player.setPosition(position)
        self.lrc_play.restart_thread()


if __name__ == '__main__':
    '''
    from PyQt5.QtCore import *
    from PyQt5.QtWidgets import *
    from PyQt5.QtMultimedia import *

    # path = "3.mp3"
    # _lrc_path = 'ずっと真夜中でいいのに。 - こんなこと騒動.lrc'
    q = music_stream_queue.MusicStreamQueue()
    q.load_playlist('list_test')
    a = MusicTask(q, con)
    a.set_volume(50)
    a.set_time(0)

    

    while True:
        b = input("?")
        if b == 'a':
            print('停止')
            a.pause()
        if b == 'b':
            a.unpause()
        if b == 'c':
            print(a.timer)
        if b == 'd1':
            a.set_trans_mode(1)
        if b == 'd2':
            a.set_trans_mode(2)

        if b == 'next':
            a.set_next_song()
        if b == 'last':
            a.set_last_song()
        if b == 'set':
            time1 = int(input("time?"))
            a.set_time(time1)
'''
